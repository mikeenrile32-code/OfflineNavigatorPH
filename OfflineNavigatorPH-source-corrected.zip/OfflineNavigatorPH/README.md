# Offline Navigator PH (Android source project)

An Android navigation prototype for the Philippines using offline vector maps, the phone's GPS, and the BRouter offline-routing service.

## What is included

- Offline Philippines map download and local map rendering (Mapsforge `.map` file).
- GPS current-location marker using Android's GPS provider.
- Tap the map to set a destination without internet.
- Online place-name search while internet is available (Nominatim / OpenStreetMap).
- Offline route calculation through the BRouter Android service.
- Route line, distance/estimated-time summary, basic voice turn prompts, and off-route recalculation.
- Motorcycle/moped, car (experimental), and walking routing profiles.

## Important: this source project is not an APK

This environment did not have the Android SDK or Gradle installed, so an installable APK could not be compiled or device-tested here. Open this folder in Android Studio, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. A real-device test is required before relying on it for travel.

## Build requirements

- Android Studio with Android SDK Platform 35.
- JDK 17.
- Gradle 8.11.1 (this archive does not include the Gradle wrapper JAR; select a local Gradle 8.11.1 installation in Android Studio, or generate a wrapper from that Gradle installation).
- Internet access during the first Gradle sync (to fetch Android and Mapsforge dependencies).
- Android device running Android 8.0 (API 26) or newer for installation/testing.

## First-time setup

### 1. Build and install this app

Open the project folder in Android Studio, sync Gradle, then build the debug APK.

### 2. Download the Philippines offline map

Open **Offline Navigator PH** and tap **Download PH map**. The app downloads the Philippines Mapsforge archive from BBBike (about 387 MB compressed), extracts the `.map` file into its private app storage, and opens it locally. Keep at least 800 MB free; more is recommended. Downloading over Wi-Fi is recommended.

Map source: https://data.bbbike.org/osm/mapsforge/region/asia/philippines/
Direct archive: https://data.bbbike.org/osm/mapsforge/region/asia/philippines/philippines.osm.mapsforge-osm.zip

The BBBike Philippines Mapsforge extract page reported an August 22, 2026 data update when this project was prepared. Map coverage and completeness depend on OpenStreetMap contributors.

### 3. Install and prepare BRouter (required for offline route calculation)

This app calls BRouter through its Android AIDL service. BRouter is a separate free companion app; it is not bundled into this APK.

- Google Play: https://play.google.com/store/apps/details?id=btools.routingapp
- F-Droid: https://f-droid.org/packages/btools.routingapp/

Open BRouter once, choose its storage folder, and use its Download Manager to download routing segments for the Philippines. BRouter stores its routing segments in `brouter/segments4` under its selected base directory. The following 5° tiles cover the main Philippines extent:

```text
E115_N0.rd5
E115_N5.rd5
E115_N10.rd5
E115_N15.rd5
E120_N0.rd5
E120_N5.rd5
E120_N10.rd5
E120_N15.rd5
E120_N20.rd5
E125_N0.rd5
E125_N5.rd5
E125_N10.rd5
E125_N20.rd5
```

BRouter segment files are updated periodically. If you manually download them, use the current files from https://brouter.de/brouter/segments4/ and place them in BRouter's `brouter/segments4` directory. The 13 listed files were about 102 MiB combined in the server listing on November 17, 2026; actual sizes can change.

Return to Offline Navigator PH. Tap **Set up offline routing** if you need to reopen BRouter. Once BRouter is installed, its service is connected automatically when this app starts.

## How to use

1. Turn on the phone's Location/GPS setting.
2. Download the Philippines map while online.
3. Install BRouter and download the routing segments for the area where you plan to travel.
4. Open this app. Wait for a GPS fix.
5. Tap a point on the map to set your destination. You can also search for a place name while online.
6. Choose Motorcycle/Moped, Car, or Walking, then tap **Route offline**.
7. Start navigation. The app keeps the screen awake while navigation is active and speaks basic turn prompts.

Place-name search requires internet. Tap-to-select destinations, downloaded map display, GPS positioning, and route calculation can work offline once the map and BRouter data are installed.

## Known limitations / safety

- This is an early prototype. It has not been compiled or field-tested on a physical Android phone in this environment.
- BRouter is a separate companion app and must have the correct routing segments and profile files installed. If BRouter reports a missing segment/profile, offline routing will fail until its data is installed.
- BRouter describes its car profile as experimental; turn restrictions may not be considered. Do not rely on the car profile as authoritative navigation. Always follow road signs, legal restrictions, and local conditions.
- Voice prompts are generated from route geometry and are basic; they are not lane guidance and may not identify road names.
- No live traffic, incidents, weather, transit, or online rerouting is available while offline.
- Map and routing data can be incomplete or outdated. Check important routes before departure and keep a backup navigation method.
- The app currently tracks GPS while it is in the foreground; it is not a full background-navigation foreground service.
- Nominatim search is online-only and should be used responsibly. It is not an offline address index.

## Open data and licenses

- Map data: © OpenStreetMap contributors, licensed under the Open Database License (ODbL): https://www.openstreetmap.org/copyright
- Mapsforge libraries: LGPL-3.0-or-later: https://github.com/mapsforge/mapsforge
- BRouter: MIT License: https://github.com/abrensch/brouter
- BBBike provides the map extract: https://www.bbbike.org/

This app is an independent project and is not affiliated with Google Maps, OpenStreetMap Foundation, BBBike, or the BRouter developers.
