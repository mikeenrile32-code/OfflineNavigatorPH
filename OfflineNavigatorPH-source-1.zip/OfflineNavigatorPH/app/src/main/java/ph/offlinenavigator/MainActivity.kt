package ph.offlinenavigator

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import btools.routingapp.IBRouterService
import org.mapsforge.core.graphics.Color
import org.mapsforge.core.graphics.Style
import org.mapsforge.core.model.LatLong
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.layer.overlay.FixedPixelCircle
import org.mapsforge.map.layer.overlay.Polyline
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.internal.MapsforgeThemes
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : Activity(), LocationListener, TextToSpeech.OnInitListener {

    companion object {
        private const val LOCATION_PERMISSION_REQUEST = 501
        private const val PH_MAP_URL = "https://data.bbbike.org/osm/mapsforge/region/asia/philippines/philippines.osm.mapsforge-osm.zip"
        private const val BROUTER_PACKAGE = "btools.routingapp"
        private const val BROUTER_SERVICE = "btools.routingapp.BRouterService"
    }

    private lateinit var mapView: MapView
    private lateinit var statusText: TextView
    private lateinit var searchInput: EditText
    private lateinit var profileSpinner: Spinner
    private lateinit var downloadManager: DownloadManager
    private lateinit var locationManager: LocationManager
    private var tileLayer: TileRendererLayer? = null
    private var routeLine: Polyline? = null
    private var currentMarker: FixedPixelCircle? = null
    private var destinationMarker: FixedPixelCircle? = null
    private var currentLocation: LatLong? = null
    private var destination: LatLong? = null
    private var routePoints: List<LatLong> = emptyList()
    private var cumulativeMeters: DoubleArray = doubleArrayOf()
    private var maneuvers: List<Maneuver> = emptyList()
    private val announcedManeuvers = mutableSetOf<Int>()
    private var isNavigating = false
    private var centeredOnGps = false
    private var lastRerouteAt = 0L
    private var routerService: IBRouterService? = null
    private var routerBound = false
    private var pendingDownloadId = -1L
    private var receiverRegistered = false
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var downX = 0f
    private var downY = 0f

    private data class Maneuver(val atMeters: Double, val direction: String)

    private val routerConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            routerService = IBRouterService.Stub.asInterface(service)
            statusText.text = "Offline routing engine connected. Choose a destination."
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            routerService = null
            statusText.text = "BRouter disconnected. Reopen routing setup."
        }
    }

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id != pendingDownloadId) return
            val cursor = downloadManager.query(DownloadManager.Query().setFilterById(id))
            cursor.use {
                if (!it.moveToFirst()) return
                val state = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                if (state == DownloadManager.STATUS_SUCCESSFUL) {
                    statusText.text = "Map downloaded. Preparing offline map…"
                    extractMapArchive()
                } else {
                    val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    statusText.text = "Map download failed (code $reason). Try again on Wi-Fi."
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)
        setContentView(R.layout.activity_main)

        mapView = findViewById(R.id.mapView)
        statusText = findViewById(R.id.statusText)
        searchInput = findViewById(R.id.searchInput)
        profileSpinner = findViewById(R.id.profileSpinner)
        downloadManager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        tts = TextToSpeech(this, this)

        mapView.setBuiltInZoomControls(true)
        mapView.setCenter(LatLong(12.8797, 121.7740))
        mapView.setZoomLevel(6.toByte())

        findViewById<Button>(R.id.downloadMapButton).setOnClickListener { confirmMapDownload() }
        findViewById<Button>(R.id.myLocationButton).setOnClickListener { goToMyLocation() }
        findViewById<Button>(R.id.searchButton).setOnClickListener { searchPlace(searchInput.text.toString().trim()) }
        findViewById<Button>(R.id.routeButton).setOnClickListener { calculateOfflineRoute() }
        findViewById<Button>(R.id.navigateButton).setOnClickListener { startNavigation() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopNavigation() }
        findViewById<Button>(R.id.routingSetupButton).setOnClickListener { showRoutingSetup() }

        mapView.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.hypot((event.x - downX).toDouble(), (event.y - downY).toDouble())
                    if (moved < 14 && tileLayer != null) {
                        val point = mapView.mapViewProjection.fromPixels(event.x.toDouble(), event.y.toDouble())
                        if (point != null) setDestination(point, false)
                    }
                }
            }
            false
        }

        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(downloadReceiver, filter)
        }
        receiverRegistered = true
        loadOfflineMapIfPresent()
        statusText.text = "Download the PH map. Tap the map to choose a destination."
    }

    override fun onStart() {
        super.onStart()
        connectBRouter()
    }

    override fun onResume() {
        super.onResume()
        startGpsUpdates()
    }

    override fun onPause() {
        stopGpsUpdates()
        super.onPause()
    }

    override fun onStop() {
        if (routerBound) {
            try { unbindService(routerConnection) } catch (_: Exception) { }
            routerBound = false
            routerService = null
        }
        super.onStop()
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(downloadReceiver) } catch (_: Exception) { }
        }
        stopNavigation()
        mapView.destroyAll()
        AndroidGraphicFactory.clearResourceMemoryCache()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    private fun mapFile(): File = File(File(filesDir, "maps"), "philippines.map")

    private fun loadOfflineMapIfPresent() {
        val file = mapFile()
        if (file.exists() && file.length() > 10_000_000L) {
            try {
                renderMap(file)
                statusText.text = "Philippines offline map ready. Tap the map to set destination."
            } catch (e: Exception) {
                statusText.text = "Map could not be opened: ${e.localizedMessage}"
            }
        }
    }

    private fun renderMap(file: File) {
        val cache = AndroidUtil.createTileCache(
            this,
            "ph-offline-cache",
            mapView.model.displayModel.tileSize,
            1f,
            mapView.model.frameBufferModel.overdrawFactor
        )
        val dataStore = MapFile(FileInputStream(file))
        val layer = TileRendererLayer(cache, dataStore, mapView.model.mapViewPosition, AndroidGraphicFactory.INSTANCE)
        layer.setXmlRenderTheme(MapsforgeThemes.MOTORIDER)
        mapView.layerManager.layers.add(layer)
        tileLayer = layer
        mapView.setCenter(LatLong(12.8797, 121.7740))
        mapView.setZoomLevel(6.toByte())
        mapView.layerManager.redrawLayers()
    }

    private fun confirmMapDownload() {
        if (mapFile().exists() && mapFile().length() > 10_000_000L) {
            Toast.makeText(this, "Philippines offline map is already installed.", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Download Philippines offline map")
            .setMessage("The map archive is about 387 MB. Keep at least 800 MB of free storage. Download while connected to Wi-Fi for best results.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Download") { _, _ -> startMapDownload() }
            .show()
    }

    private fun startMapDownload() {
        try {
            val request = DownloadManager.Request(Uri.parse(PH_MAP_URL))
                .setTitle("Offline Navigator PH map")
                .setDescription("Downloading OpenStreetMap data for the Philippines")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "philippines-mapsforge.zip")
            pendingDownloadId = downloadManager.enqueue(request)
            statusText.text = "Map download started. Check the Android notification for progress."
        } catch (e: Exception) {
            statusText.text = "Could not start map download: ${e.localizedMessage}"
        }
    }

    private fun extractMapArchive() {
        Thread {
            try {
                val zipFile = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "philippines-mapsforge.zip")
                val target = mapFile()
                target.parentFile?.mkdirs()
                var found = false
                ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zip ->
                    var entry = zip.nextEntry
                    val buffer = ByteArray(64 * 1024)
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name.lowercase(Locale.ROOT).endsWith(".map")) {
                            FileOutputStream(target).use { output ->
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count <= 0) break
                                    output.write(buffer, 0, count)
                                }
                            }
                            found = true
                            break
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
                zipFile.delete()
                runOnUiThread {
                    if (found) {
                        try {
                            renderMap(target)
                            statusText.text = "Philippines offline map installed. GPS and map now work offline."
                        } catch (e: Exception) {
                            statusText.text = "Map was extracted but could not be opened: ${e.localizedMessage}"
                        }
                    } else {
                        statusText.text = "The downloaded archive did not contain a .map file."
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Could not prepare map: ${e.localizedMessage}" }
            }
        }.start()
    }

    private fun connectBRouter() {
        if (routerBound || routerService != null) return
        val intent = Intent().setComponent(ComponentName(BROUTER_PACKAGE, BROUTER_SERVICE))
        try {
            routerBound = bindService(intent, routerConnection, Context.BIND_AUTO_CREATE)
        } catch (_: Exception) {
            routerBound = false
        }
    }

    private fun showRoutingSetup() {
        AlertDialog.Builder(this)
            .setTitle("Set up offline route calculation")
            .setMessage(
                "1. Install the free BRouter companion app.\n" +
                "2. Open BRouter and choose its storage folder.\n" +
                "3. In BRouter's Download Manager, download the routing segments covering the Philippines.\n" +
                "4. Return here. This app will request routes from BRouter without internet.\n\n" +
                "The Philippines needs these 5° routing tiles: E115_N0, E115_N5, E115_N10, E115_N15, " +
                "E120_N0, E120_N5, E120_N10, E120_N15, E120_N20, E125_N0, E125_N5, E125_N10 and E125_N20."
            )
            .setNegativeButton("Close", null)
            .setPositiveButton("Open / Install BRouter") { _, _ -> openBRouter() }
            .show()
    }

    private fun openBRouter() {
        val launch = packageManager.getLaunchIntentForPackage(BROUTER_PACKAGE)
        if (launch != null) {
            startActivity(launch)
        } else {
            val play = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$BROUTER_PACKAGE"))
            startActivity(play)
        }
    }

    private fun setDestination(point: LatLong, moveMap: Boolean) {
        destination = point
        destinationMarker?.let { mapView.layerManager.layers.remove(it) }
        val fill = createPaint(Color.RED, 1f, Style.FILL)
        val stroke = createPaint(Color.WHITE, 3f, Style.STROKE)
        val marker = FixedPixelCircle(point, 11, fill, stroke)
        destinationMarker = marker
        mapView.layerManager.layers.add(marker)
        if (moveMap) mapView.setCenter(point)
        mapView.layerManager.redrawLayers()
        statusText.text = "Destination set: ${formatCoord(point)}. Press Route offline."
        findViewById<Button>(R.id.navigateButton).isEnabled = false
    }

    private fun createPaint(color: Int, width: Float, style: Style): org.mapsforge.core.graphics.Paint {
        val paint = AndroidGraphicFactory.INSTANCE.createPaint()
        paint.setColor(AndroidGraphicFactory.INSTANCE.createColor(color))
        paint.setStrokeWidth(width)
        paint.setStyle(style)
        return paint
    }

    private fun startGpsUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST)
            return
        }
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 3f, this)
                locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
            } else {
                statusText.text = "Turn on Location / GPS to show your position."
            }
        } catch (e: SecurityException) {
            statusText.text = "Location permission is required for GPS."
        }
    }

    private fun stopGpsUpdates() {
        try { locationManager.removeUpdates(this) } catch (_: SecurityException) { }
    }

    @Deprecated("Deprecated by Android API")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startGpsUpdates()
        } else if (requestCode == LOCATION_PERMISSION_REQUEST) {
            Toast.makeText(this, "GPS permission is needed to navigate.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onLocationChanged(location: Location) {
        val point = LatLong(location.latitude, location.longitude)
        currentLocation = point
        currentMarker?.let { mapView.layerManager.layers.remove(it) }
        val fill = createPaint(Color.BLUE, 1f, Style.FILL)
        val stroke = createPaint(Color.WHITE, 3f, Style.STROKE)
        val marker = FixedPixelCircle(point, 10, fill, stroke)
        currentMarker = marker
        mapView.layerManager.layers.add(marker)
        if (!centeredOnGps) {
            mapView.setCenter(point)
            mapView.setZoomLevel(15.toByte())
            centeredOnGps = true
        }
        if (isNavigating) {
            mapView.setCenter(point)
            updateNavigationProgress(point)
        }
        mapView.layerManager.redrawLayers()
    }

    @Deprecated("Deprecated by Android API")
    override fun onProviderEnabled(provider: String) { }
    @Deprecated("Deprecated by Android API")
    override fun onProviderDisabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) statusText.text = "GPS is turned off. Navigation paused."
    }
    @Deprecated("Deprecated by Android API")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }

    private fun goToMyLocation() {
        val point = currentLocation
        if (point == null) {
            startGpsUpdates()
            Toast.makeText(this, "Waiting for GPS fix…", Toast.LENGTH_SHORT).show()
        } else {
            mapView.setCenter(point)
            mapView.setZoomLevel(16.toByte())
        }
    }

    private fun searchPlace(query: String) {
        if (query.isBlank()) {
            Toast.makeText(this, "Enter a place name first.", Toast.LENGTH_SHORT).show()
            return
        }
        statusText.text = "Searching online…"
        Thread {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=$encoded")
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 12000
                connection.readTimeout = 12000
                connection.setRequestProperty("User-Agent", "OfflineNavigatorPH/0.1 (Android navigation app)")
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val results = org.json.JSONArray(body)
                if (results.length() == 0) throw IllegalStateException("No matching place found.")
                val first = results.getJSONObject(0)
                val point = LatLong(first.getString("lat").toDouble(), first.getString("lon").toDouble())
                val label = first.optString("display_name", query)
                runOnUiThread {
                    setDestination(point, true)
                    statusText.text = "Found: ${label.take(90)}. Press Route offline."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Search needs internet. Offline: tap a point on the downloaded map."
                }
            }
        }.start()
    }

    private fun calculateOfflineRoute() {
        val from = currentLocation
        val to = destination
        if (from == null) {
            startGpsUpdates()
            Toast.makeText(this, "Waiting for GPS location before routing.", Toast.LENGTH_LONG).show()
            return
        }
        if (to == null) {
            Toast.makeText(this, "Tap the map or search for a destination first.", Toast.LENGTH_LONG).show()
            return
        }
        val service = routerService
        if (service == null) {
            statusText.text = "BRouter is not connected. Set up the offline routing engine first."
            showRoutingSetup()
            return
        }
        val profile = when (profileSpinner.selectedItemPosition) {
            1 -> "car-test"
            2 -> "shortest"
            else -> "moped"
        }
        if (profile == "car-test") {
            Toast.makeText(this, "BRouter car profile is experimental. Verify every road and sign.", Toast.LENGTH_LONG).show()
        }
        statusText.text = "Calculating route offline…"
        findViewById<Button>(R.id.routeButton).isEnabled = false
        Thread {
            try {
                val params = Bundle().apply {
                    putString("lonlats", "${from.longitude},${from.latitude}|${to.longitude},${to.latitude}")
                    putString("profile", profile)
                    putString("trackFormat", "gpx")
                    putString("timode", "4")
                    putString("maxRunningTime", "60")
                    putString("acceptCompressedResult", "false")
                }
                val gpx = service.getTrackFromParams(params)
                if (gpx.isNullOrBlank()) throw IllegalStateException("BRouter returned an empty route.")
                if (!gpx.trimStart().startsWith("<")) throw IllegalStateException(gpx.take(180))
                val points = parseGpx(gpx)
                if (points.size < 2) throw IllegalStateException("No road route found. Check that the required PH routing segments are installed.")
                runOnUiThread { showCalculatedRoute(points, profile) }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Offline route failed: ${e.localizedMessage ?: "Unknown error"}. Check BRouter segments and profile."
                    findViewById<Button>(R.id.routeButton).isEnabled = true
                }
            }
        }.start()
    }

    private fun parseGpx(gpx: String): List<LatLong> {
        val points = mutableListOf<LatLong>()
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(gpx))
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && (parser.name == "trkpt" || parser.name == "rtept")) {
                val lat = parser.getAttributeValue(null, "lat")?.toDoubleOrNull()
                val lon = parser.getAttributeValue(null, "lon")?.toDoubleOrNull()
                if (lat != null && lon != null) points.add(LatLong(lat, lon))
            }
            event = parser.next()
        }
        return points
    }

    private fun showCalculatedRoute(points: List<LatLong>, profile: String) {
        routeLine?.let { mapView.layerManager.layers.remove(it) }
        val routePaint = createPaint(Color.BLUE, 8f, Style.STROKE)
        val line = Polyline(routePaint, AndroidGraphicFactory.INSTANCE)
        line.setPoints(points)
        mapView.layerManager.layers.add(line)
        routeLine = line
        routePoints = points
        cumulativeMeters = DoubleArray(points.size)
        for (i in 1 until points.size) cumulativeMeters[i] = cumulativeMeters[i - 1] + distanceMeters(points[i - 1], points[i])
        maneuvers = buildManeuvers(points)
        announcedManeuvers.clear()
        val distance = cumulativeMeters.lastOrNull() ?: 0.0
        val speedKmh = when (profile) { "shortest" -> 4.5; "car-test" -> 35.0; else -> 28.0 }
        val etaMinutes = (distance / 1000.0 / speedKmh * 60.0).roundToInt()
        statusText.text = "Offline route ready • ${formatDistance(distance)} • about $etaMinutes min. Start navigation when safe."
        findViewById<Button>(R.id.navigateButton).isEnabled = true
        findViewById<Button>(R.id.routeButton).isEnabled = true
        mapView.setCenter(currentLocation ?: points.first())
        mapView.setZoomLevel(14.toByte())
        mapView.layerManager.redrawLayers()
    }

    private fun buildManeuvers(points: List<LatLong>): List<Maneuver> {
        if (points.size < 3) return emptyList()
        val result = mutableListOf<Maneuver>()
        var lastAt = -150.0
        for (i in 1 until points.lastIndex) {
            val before = bearing(points[i - 1], points[i])
            val after = bearing(points[i], points[i + 1])
            var delta = (after - before + 540.0) % 360.0 - 180.0
            if (abs(delta) >= 48.0 && cumulativeMeters[i] - lastAt >= 110.0) {
                result.add(Maneuver(cumulativeMeters[i], if (delta > 0) "right" else "left"))
                lastAt = cumulativeMeters[i]
            }
        }
        return result
    }

    private fun startNavigation() {
        if (routePoints.size < 2) return
        isNavigating = true
        announcedManeuvers.clear()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        findViewById<Button>(R.id.navigateButton).isEnabled = false
        findViewById<Button>(R.id.stopButton).isEnabled = true
        speak("Navigation started. Follow the blue route.")
        statusText.text = "Navigation active. Keep GPS enabled and follow the blue route."
    }

    private fun stopNavigation() {
        isNavigating = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (::mapView.isInitialized) {
            findViewById<Button>(R.id.navigateButton).isEnabled = routePoints.size > 1
            findViewById<Button>(R.id.stopButton).isEnabled = false
        }
    }

    private fun updateNavigationProgress(point: LatLong) {
        if (routePoints.isEmpty()) return
        var nearestIndex = 0
        var nearestDistance = Double.MAX_VALUE
        for (i in routePoints.indices) {
            val d = distanceMeters(point, routePoints[i])
            if (d < nearestDistance) {
                nearestDistance = d
                nearestIndex = i
            }
        }
        val progress = cumulativeMeters.getOrElse(nearestIndex) { 0.0 }
        if (nearestDistance > 120.0 && System.currentTimeMillis() - lastRerouteAt > 30000L) {
            lastRerouteAt = System.currentTimeMillis()
            statusText.text = "You may be off route. Recalculating offline…"
            calculateOfflineRoute()
            return
        }
        val nextIndex = maneuvers.indices.firstOrNull { maneuvers[it].atMeters > progress && !announcedManeuvers.contains(it) } ?: -1
        if (nextIndex >= 0) {
            val next = maneuvers[nextIndex]
            val remaining = next.atMeters - progress
            if (remaining in 20.0..250.0) {
                val meters = (remaining / 50.0).roundToInt() * 50
                speak("Sa loob ng $meters metro, lumiko sa ${if (next.direction == "right") "kanan" else "kaliwa"}.")
                announcedManeuvers.add(nextIndex)
                statusText.text = "In ${meters} m, turn ${next.direction}."
            }
        }
        val end = routePoints.last()
        if (distanceMeters(point, end) < 25.0) {
            speak("Nakarating ka na sa destinasyon.")
            statusText.text = "You have arrived."
            stopNavigation()
        }
    }

    private fun speak(message: String) {
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "nav-${System.currentTimeMillis()}")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("fil", "PH"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
            ttsReady = true
        }
    }

    private fun formatCoord(point: LatLong): String = "${"%.5f".format(point.latitude)}, ${"%.5f".format(point.longitude)}"

    private fun formatDistance(meters: Double): String = if (meters >= 1000) "${"%.1f".format(meters / 1000)} km" else "${meters.roundToInt()} m"

    private fun distanceMeters(a: LatLong, b: LatLong): Double {
        val earth = 6371000.0
        val dLat = Math.toRadians(b.latitude - a.latitude)
        val dLon = Math.toRadians(b.longitude - a.longitude)
        val lat1 = Math.toRadians(a.latitude)
        val lat2 = Math.toRadians(b.latitude)
        val h = sin(dLat / 2) * sin(dLat / 2) + cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * earth * atan2(sqrt(h), sqrt(max(0.0, 1.0 - h)))
    }

    private fun bearing(a: LatLong, b: LatLong): Double {
        val lat1 = Math.toRadians(a.latitude)
        val lat2 = Math.toRadians(b.latitude)
        val dLon = Math.toRadians(b.longitude - a.longitude)
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }
}
